const path = require("path");
const express = require("express");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const methodOverride = require("method-override");

const { connectDB } = require("./config/db");
const { addUserToLocals } = require("./middleware/auth");

const authRoutes = require("./routes/auth");
const bookRoutes = require("./routes/books");
const chatRoutes = require("./routes/chat");

const app = express();

// ✅ HARD-CODED SETTINGS (no .env)
const PORT = 3000;
const MONGO_URI = "mongodb://127.0.0.1:27017/book-binder-simple";
const SESSION_SECRET = "my_super_secret_key_12345";

async function start() {
  console.log("✅ server.js started...");

  // 1) Connect DB
  console.log("⏳ Connecting to MongoDB...");
  await connectDB(MONGO_URI);

  // 2) View engine
  app.set("view engine", "ejs");
  app.set("views", path.join(__dirname, "views"));

  // 3) Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(methodOverride("_method"));
  app.use(express.static(path.join(__dirname, "public")));

  // 4) Session
  app.use(
    session({
      secret: SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: "lax" },
      store: MongoStore.create({ mongoUrl: MONGO_URI })
    })
  );

  app.use(addUserToLocals);

  // 5) Routes
  app.get("/", (req, res) => res.render("home", { title: "Home" }));
  app.use("/auth", authRoutes);
  app.use("/books", bookRoutes);
  app.use("/chat", chatRoutes);

  // 6) 404
  app.use((req, res) => {
    res.status(404).render("error", { title: "Not Found", message: "Page not found." });
  });

  // 7) Start server ✅
  app.listen(PORT, () => {
    console.log(`✅ Server running at: http://localhost:${PORT}`);
  });
}

// If anything fails, you will SEE it now
start().catch((err) => {
  console.error("❌ Startup failed:", err);
});