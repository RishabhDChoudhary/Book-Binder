# BookBinder (Simple) – MEN Stack CRUD + Ollama Chatbot

This is a **beginner-friendly** CRUD web app using:
- **MongoDB + Mongoose**
- **Express + Node.js**
- **EJS templates**
- **Session-based authentication**
- **Ollama chatbot** (local LLM)

## 1) Setup
1. Install Node.js (LTS) and MongoDB (or use MongoDB Atlas).
2. Open this folder in VS Code.

## 2) Install & run
```bash
npm install
npm run dev
```

Open: http://localhost:3000

## 3) Ollama chatbot setup (optional but required for your project)
1. Install Ollama and run it
2. Pull a model (example):
```bash
ollama pull llama3
```
3. Keep Ollama running, then open the app:
- Chat page: `/chat`

If Ollama is not running, the chat page will show a helpful error message.

## 4) CRUD Pages
- List books: `GET /books`
- New book form: `GET /books/new`
- Create book: `POST /books`
- Show book details: `GET /books/:id`
- Edit form: `GET /books/:id/edit`
- Update book: `PUT /books/:id`
- Delete confirm page: `GET /books/:id/delete`
- Delete book: `DELETE /books/:id`
