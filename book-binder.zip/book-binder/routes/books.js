const express = require("express");
const router = express.Router();
const axios = require("axios");

const Book = require("../models/Book");
const { requireLogin, requireOwner } = require("../middleware/auth");

// helper: load book by id
async function loadBook(req, res, next) {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).render("error", { title: "Not Found", message: "Book not found." });
    req.book = book;
    next();
  } catch {
    res.status(400).render("error", { title: "Error", message: "Invalid book id." });
  }
}

// ✅ Google Books cover auto-fetch
async function fetchGoogleBooksCover(title, author) {
  try {
    const q = `intitle:${title}${author ? `+inauthor:${author}` : ""}`;
    const url = `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(q)}&maxResults=1`;

    const resp = await axios.get(url, { timeout: 8000 });
    const item = resp.data?.items?.[0];

    const thumb =
      item?.volumeInfo?.imageLinks?.thumbnail ||
      item?.volumeInfo?.imageLinks?.smallThumbnail ||
      "";

    // Google returns http sometimes — convert to https
    return thumb ? thumb.replace("http://", "https://") : "";
  } catch (err) {
    return "";
  }
}

// LIST
router.get("/", requireLogin, async (req, res) => {
  const books = await Book.find({ owner: req.session.user._id }).sort({ updatedAt: -1 });
  res.render("books/index", { title: "My Library", books });
});

// NEW
router.get("/new", requireLogin, (req, res) => {
  res.render("books/new", { title: "Add Book" });
});

// CREATE
router.post("/", requireLogin, async (req, res) => {
  try {
    let { title, author, status, progress, notes, coverUrl, rating } = req.body;

    if (!title || !author) {
      req.session.flash = { type: "error", message: "Title & Author are required." };
      return res.redirect("/books/new");
    }

    const progressNum = Number(progress ?? 0);
    const ratingNum = Number(rating ?? 0);

    // ✅ Auto cover fill if user didn't provide one
    let finalCover = (coverUrl || "").trim();
    if (!finalCover) {
      finalCover = await fetchGoogleBooksCover(title, author);
    }

    const book = await Book.create({
      title: title.trim(),
      author: author.trim(),
      status,
      progress: Number.isFinite(progressNum) ? progressNum : 0,
      notes: (notes || "").trim(),
      coverUrl: finalCover,
      rating: Number.isFinite(ratingNum) ? ratingNum : 0,
      owner: req.session.user._id
    });

    req.session.flash = { type: "success", message: "Book created! Cover auto-fetched if available." };
    res.redirect(`/books/${book._id}`);
  } catch (err) {
    console.error(err);
    res.status(500).render("error", { title: "Error", message: "Could not create book." });
  }
});

// SHOW
router.get("/:id", requireLogin, loadBook, requireOwner, (req, res) => {
  res.render("books/show", { title: req.book.title, book: req.book });
});

// EDIT
router.get("/:id/edit", requireLogin, loadBook, requireOwner, (req, res) => {
  res.render("books/edit", { title: `Edit: ${req.book.title}`, book: req.book });
});

// UPDATE
router.put("/:id", requireLogin, loadBook, requireOwner, async (req, res) => {
  try {
    const { title, author, status, progress, notes, coverUrl, rating } = req.body;

    req.book.title = title.trim();
    req.book.author = author.trim();
    req.book.status = status;

    const progressNum = Number(progress ?? 0);
    req.book.progress = Number.isFinite(progressNum) ? progressNum : 0;

    const ratingNum = Number(rating ?? 0);
    req.book.rating = Number.isFinite(ratingNum) ? ratingNum : 0;

    req.book.notes = (notes || "").trim();

    // keep manual override if user updates coverUrl
    req.book.coverUrl = (coverUrl || "").trim();

    await req.book.save();

    req.session.flash = { type: "success", message: "Book updated!" };
    res.redirect(`/books/${req.book._id}`);
  } catch (err) {
    console.error(err);
    res.status(500).render("error", { title: "Error", message: "Could not update book." });
  }
});

// DELETE CONFIRM
router.get("/:id/delete", requireLogin, loadBook, requireOwner, (req, res) => {
  res.render("books/delete", { title: `Delete: ${req.book.title}`, book: req.book });
});

// DELETE
router.delete("/:id", requireLogin, loadBook, requireOwner, async (req, res) => {
  try {
    await req.book.deleteOne();
    req.session.flash = { type: "success", message: "Book deleted." };
    res.redirect("/books");
  } catch (err) {
    console.error(err);
    res.status(500).render("error", { title: "Error", message: "Could not delete book." });
  }
});

module.exports = router;