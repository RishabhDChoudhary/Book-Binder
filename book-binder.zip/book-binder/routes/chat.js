const express = require("express");
const router = express.Router();
const axios = require("axios");
const { requireLogin } = require("../middleware/auth");

router.get("/", requireLogin, (req, res) => {
  res.render("chat/index", { title: "Chatbot", answer: null, prompt: "" });
});

router.post("/", requireLogin, async (req, res) => {
  const prompt = (req.body.prompt || "").trim();
  if (!prompt) {
    return res.render("chat/index", { title: "Chatbot", answer: "Please type a message first.", prompt: "" });
  }

  // ✅ hardcoded Ollama settings (no .env)
  const baseUrl = "http://127.0.0.1:11434";
  const model = "llama3";

  try {
    const resp = await axios.post(
      `${baseUrl}/api/generate`,
      { model, prompt, stream: false },
      { timeout: 120000 } // ✅ 120 seconds timeout so it won’t hang forever
    );

    const answer = resp.data?.response || "(No response)";
    return res.render("chat/index", { title: "Chatbot", answer, prompt });
  } catch (err) {
    // Helpful message
    let msg = "Chatbot failed.";
    if (err.code === "ECONNABORTED") msg = "Ollama took too long to respond (timeout). Try again after the model finishes loading.";
    else if (err.response) msg = `Ollama error: ${err.response.status} ${err.response.statusText}`;
    else msg = "Could not reach Ollama. Make sure `ollama serve` is running.";

    return res.render("chat/index", { title: "Chatbot", answer: msg, prompt });
  }
});

module.exports = router;