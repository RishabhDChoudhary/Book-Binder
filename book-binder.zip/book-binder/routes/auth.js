const express = require("express");
const router = express.Router();
const User = require("../models/User");

router.get("/signup", (req, res) => {
  res.render("auth/signup", { title: "Sign Up" });
});

router.post("/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      req.session.flash = { type: "error", message: "All fields are required." };
      return res.redirect("/auth/signup");
    }
    if (password.length < 6) {
      req.session.flash = { type: "error", message: "Password must be at least 6 characters." };
      return res.redirect("/auth/signup");
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      req.session.flash = { type: "error", message: "Email already exists." };
      return res.redirect("/auth/signup");
    }

    const passwordHash = await User.hashPassword(password);
    const user = await User.create({ name, email: email.toLowerCase(), passwordHash });

    req.session.user = { _id: user._id, name: user.name, email: user.email };
    req.session.flash = { type: "success", message: "Account created!" };
    res.redirect("/books");
  } catch (err) {
    console.error(err);
    res.status(500).render("error", { title: "Error", message: "Signup failed." });
  }
});

router.get("/login", (req, res) => {
  res.render("auth/login", { title: "Log In" });
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email: (email || "").toLowerCase() });
    if (!user) {
      req.session.flash = { type: "error", message: "Invalid email or password." };
      return res.redirect("/auth/login");
    }

    const ok = await user.verifyPassword(password || "");
    if (!ok) {
      req.session.flash = { type: "error", message: "Invalid email or password." };
      return res.redirect("/auth/login");
    }

    req.session.user = { _id: user._id, name: user.name, email: user.email };
    req.session.flash = { type: "success", message: "Logged in!" };
    res.redirect("/books");
  } catch (err) {
    console.error(err);
    res.status(500).render("error", { title: "Error", message: "Login failed." });
  }
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.redirect("/");
  });
});

module.exports = router;
