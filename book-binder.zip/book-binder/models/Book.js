const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 120 },
    author: { type: String, required: true, trim: true, maxlength: 80 },

    status: { type: String, enum: ["To Read", "Reading", "Finished"], default: "To Read" },
    progress: { type: Number, min: 0, max: 100, default: 0 },

    // ✅ NEW: cover + rating
    coverUrl: { type: String, trim: true, default: "" },
    rating: { type: Number, min: 0, max: 5, default: 0 },

    notes: { type: String, trim: true, maxlength: 2000 },

    owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Book", bookSchema);