function addUserToLocals(req, res, next) {
  res.locals.currentUser = req.session.user || null;
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  next();
}

function requireLogin(req, res, next) {
  if (!req.session.user) {
    req.session.flash = { type: "error", message: "Please log in first." };
    return res.redirect("/auth/login");
  }
  next();
}

function requireOwner(req, res, next) {
  const userId = req.session.user?._id;
  if (!req.book) return res.redirect("/books");
  if (String(req.book.owner) !== String(userId)) {
    req.session.flash = { type: "error", message: "Not allowed. This is not your book." };
    return res.redirect("/books");
  }
  next();
}

module.exports = { addUserToLocals, requireLogin, requireOwner };
